package com.expense.expensetracker.reporitory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.expense.expensetracker.entity.Expense;

public interface ExpenseRepo extends JpaRepository<Expense, Long> {

}
