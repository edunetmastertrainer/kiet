package com.expense.expensetracker.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.expense.expensetracker.entity.Expense;
import com.expense.expensetracker.service.ExpenseService;

@Controller
public class ExpenseController {
	@Autowired
	ExpenseService expenseService;
	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("expenses",expenseService.getAllExpenses());
		return "home";
	}
	@GetMapping("/addexpense")
	public String addexpense() {
		return "addexpenseform";
	}
	@PostMapping("/addexpense")
	public String addexp(Expense expense) {
		expense.setDate(LocalDate.now());
		expenseService.addExpense(expense);
		return "redirect:/";
	}
	
	@GetMapping("/deleteexpense/{id}")
	public String deleteexpense(@PathVariable Long id) {
		expenseService.deleteExpense(id);
		return "redirect:/";
	}
	
}
