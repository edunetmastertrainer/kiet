package com.expense.expensetracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.expensetracker.entity.Expense;
import com.expense.expensetracker.reporitory.ExpenseRepo;

@Service
public class ExpenseService {
	@Autowired
	ExpenseRepo expenserepo;
	//Add new expense
	public void addExpense(Expense expense) {
		expenserepo.save(expense);
	}
	//delete expense by id
	public void deleteExpense(Long id) {
		expenserepo.deleteById(id);
	}
	//display all expenses
	public List<Expense> getAllExpenses() {
		return expenserepo.findAll();
	}
	//update expense by id
	public void updateExpense(Expense expense) {
		expenserepo.save(expense);
	}
}
